Team 3 – Customers Project

There should be a button that lists of all of our customers

There should be a button that lists all countries

There should be a button that allows entry of a flight number and lists the
customers on a flight (Reservations Table)

There should be a button that lists all the records in the RESHIST table.

There should be a button that allows entry of a flight number and shows the
customers seat.

There should be a button that allows the entry of a customer number and shows
the customers password.

There should be a button that allows the entry of a reservation number and then
lists the customer’s information.

Add a Customer to the Customer table

Add a Country to the Country table

Add a boat to the table BOAT_TYPE2

Add a car to the table CARS
